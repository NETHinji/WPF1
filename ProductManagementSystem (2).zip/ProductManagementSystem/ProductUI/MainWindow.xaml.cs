﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity;
using Exceptions;
using BusinessLayer;
using System.Data;

namespace ProductUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddCategory_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product p = new Product
                {                    
                    ProductName = txtPName.Text,
                    Description = txtDescp.Text,
                    UnitPrice = decimal.Parse(txtUP.Text),
                    Stock = int.Parse(txtStock.Text),
                    Category = int.Parse(cmbCategories.SelectedValue.ToString())
                };
                ProductBL pb = new ProductBL();
                int pid = pb.AddProduct(p);
                MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", pid),
                    "Product Management System");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ProductBL pb = new ProductBL();
                DataTable dt = pb.GetCategories();
                if (dt != null)
                {
                    cmbCategories.ItemsSource = dt.DefaultView;
                    cmbCategories.DisplayMemberPath = "CategoryName";
                    cmbCategories.SelectedValuePath = "CategoryId";
                }
                else
                {
                    MessageBox.Show("Table is empty", "Product Management System");
                }
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }
    }
}
