﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.Entities;
using Employee.Entities;
using Employee.Exception;

namespace Employee.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            Exception.Employee e1=new E
        }
    }
}
