﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        string _myConnectionString = @"data source=ndamssql\sqlilearn;
        user id=sqluser;password=sqluser;initial catalog=training_19sep18_pune;";

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con1 = new SqlConnection(_myConnectionString))
            {
                //con1.ConnectionString = _myConnectionString;
                con1.StateChange += Con1_StateChange;
                con1.Open();
               // SqlCommand sqlcom = new SqlCommand(("insert into Employee(Employeeid, name, managerid)values(@EID,@Name,@MID)",con1);
                //sqlcom.CommandText="insert into Employee(Employeeid,name,managerid )values(11,'Soumendra',22)";

                //sqlcom.CommandText= "insert into Employee(Employeeid, name, managerid)values(@EID,@Name,@MID)";
                //SqlParameter spEid = sqlcom.Parameters.Add("@EID", SqlDbType.Int);
                //spEid.Value = 5555;

                //SqlParameter spName = sqlcom.Parameters.Add("@Name", SqlDbType.VarChar);
                //spName.Value = "Soumendra";
                //SqlParameter spMid = sqlcom.Parameters.Add("@MID", SqlDbType.Int);
                //spMid.Value = 5555;
                //sqlcom.Parameters.AddWithValue("@EID", 7648);
                //sqlcom.Parameters.AddWithValue("@Name", "Soumen");
                //sqlcom.Parameters.AddWithValue("@MID", 8647);
                //sqlcom.Connection = con1;
                DataTable dtEmployee = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter("select * from Employee", con1);
                sda.Fill(dtEmployee);
                con1.Close();
                MessageBox.Show(dtEmployee.Rows.Count.ToString());
                foreach(DataRow singleRow in dtEmployee.Rows)
                {
                    MessageBox.Show(singleRow["employeeid"].ToString() +
                        singleRow["name"].ToString());
                }
                dgSoumendra.ItemsSource = dtEmployee.DefaultView;
                //sqlcom.ExecuteNonQuery();
                //MessageBox.Show("Saved!!");
            }
        }

        private void Con1_StateChange(object sender, StateChangeEventArgs e)
        {
            if (e.CurrentState == ConnectionState.Open)
            {
                MessageBox.Show("YEA!!");
            }
            else if(e.CurrentState==ConnectionState.Closed)
            {
                MessageBox.Show("Boo");
            }
        }
    }
        
}
