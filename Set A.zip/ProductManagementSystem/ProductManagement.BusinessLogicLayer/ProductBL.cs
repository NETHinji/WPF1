﻿using System;
using ProductManagement.DataAccessLayer;
using ProductManagement.Entity;

namespace ProductManagement.BusinessLogicLayer
{
    public class ProductBL
    {
        public int AddProduct(Product p)
        {
            //bool validate = false;
            int added;
            try
            {
                //if (ValidateProduct(p))
                //{
                    ProductDL pdl = new ProductDL();
                    added=pdl.AddProduct(p);
                //}

    }
            catch (System.Exception)
            {

                throw;
            }
            return added;
            //return validate;
        }

        //private bool ValidateProduct(Product p)
        //{
        //    bool validate = true;

        //    if()
        //}
    }
}