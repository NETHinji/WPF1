﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer
{
    public class ProductDL
    {
        //create connection for Database
        SqlCommand cmd = new SqlCommand();
        static string Con = string.Empty;
        SqlConnection con1;

        static ProductDL()
        {
            Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
        }
        public ProductDL()
        {
            con1 = new SqlConnection(Con);
        }

        public int AddProduct(Product p) //adding product using stored procedures
        {

            try
            {
                cmd.CommandText = "Dheeraj.AddProduct";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@sNumber", p.SerialNumber);
                cmd.Parameters.AddWithValue("@pName", p.ProductName);
                cmd.Parameters.AddWithValue("@bname", p.BrandName);
                cmd.Parameters.AddWithValue("@pType", p.ProductType);
                cmd.Parameters.AddWithValue("@pDesc", p.ProductDesc);
                cmd.Parameters.AddWithValue("@price", p.Price);


                con1.Open();
                int Rowaffected = cmd.ExecuteNonQuery();
                return Rowaffected;


            }
            catch (System.Exception)
            {

                throw;
            }
            finally
            {
                con1.Close();
            }

        }

        public DataTable ListEmp()
        {
            DataTable dt = null;
            try
            {

                cmd.CommandText = "Dheeraj.List";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;

                con1.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (System.Exception)
            {

                throw;
            }
            return dt;
        }
    }
}