use Training_19Sep18_Pune

-----------Creating schema-------
create schema Dheeraj

----------Creating table-----------

create table Dheeraj.Product
(
SerialNumber varchar(14),
Productname varchar(30),
Brandname varchar(30),
ProductType varchar(30),
check (ProductType in ('Mobiles','Cameras','Laptops','Appliances','Accessories')),                                                 
ProductDesc varchar(100),
Price int
check (price>0)
)

----------Creating Add Procedure----------- 

alter proc Dheeraj.AddProduct
(
@sNumber varchar(14),
@pName varchar(30),
@bname varchar(30),
@pType varchar(30),
@pDesc varchar(100),
@price int
)
as
begin 
	insert into Dheeraj.Product values (@sNumber,@pName,@bname,@pType,@pDesc,@price)
end


select * from Dheeraj.Product

----------Listing table-----------

create proc Dheeraj.List
as
begin
	select * from Dheeraj.Product
end









