﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Product
    {
        //Properties
        public string SerialNumber { get; set; }
        public string ProductName { get; set; }
        public string BrandName { get; set; }
        public string ProductType { get; set; }
        public string ProductDesc { get; set; }
        public int Price { get; set; }

        public enum ProductTypeEnum //Product Type Enum
        {
            Mobiles,
            Cameras,
            Laptops,
            Appliances,
            Accessories
        }
    }
}
