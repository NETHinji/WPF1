﻿using ProductManagement.BusinessLogicLayer;
using ProductManagement.Entity;
using ProductManagement.Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProductManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product product = new Product()
                {
                    SerialNumber = txtSerial.Text,
                    ProductName = txtProductName.Text,
                    BrandName = txtBrandName.Text,
                    ProductType = cmboProduct.SelectedValue.ToString(),
                    ProductDesc = txt_ProdDesc.Text,
                    Price = Convert.ToInt32(txtProdPrice.Text)
                };

                ProductBL pbl = new ProductBL();
                int added = pbl.AddProduct(product);
                if(added!=0)
                {
                    MessageBox.Show("Product added Succesfully");
                    DataTable dt = pbl.ListEmp();
                    if (dt != null)
                    {
                        dgProduct.ItemsSource = dt.DefaultView;
                    }
                }
                else
                {
                    MessageBox.Show("Product Not added");
                }
            }
            catch (System.Exception ex)
            {

                throw;
            }
           
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach(var item in Enum.GetValues(typeof(Product.ProductTypeEnum)))
            {
                cmboProduct.Items.Add(item);
            }
        }
    }
}
