﻿namespace ProductManagement.Entity
{
    public class Product
    {
        public string SerialNumber { get; set; }
        public string ProductName { get; set; }
        public string BrandName { get; set; }
        public string ProductType { get; set; }
        public string ProductDesc { get; set; }
        public int Price { get; set; }

        public enum ProductTypeEnum
        {
            Mobiles,
            Cameras,
            Laptops,
            Appliances,
            Accessories
        }
    }
}