﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using Entity;
using Exceptions;
using System.Data;

namespace BusinessLayer
{
    public class ProductBL
    {
        public int AddProduct(Product pobj)
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.AddProduct(pobj);
            }
            catch (ProductException)
            {
                throw;
            }
        }

        public bool EditProduct(Product pobj)
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.EditProduct(pobj);
            }
            catch (ProductException)
            {
                throw;
            }
        }

        public bool DeleteProduct(int productId)
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.DeleteProduct(productId);
            }
            catch (ProductException)
            {
                throw;
            }
        }

        public Product Search(int productId)
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.Search(productId);
            }
            catch (ProductException)
            {
                throw;
            }
        }

        public DataTable Display()
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.Display();
            }
            catch (ProductException)
            {
                throw;
            }
        }

        public DataTable GetCategories()
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.GetCategories();
            }
            catch (ProductException)
            {
                throw;
            }
        }
    }
}
