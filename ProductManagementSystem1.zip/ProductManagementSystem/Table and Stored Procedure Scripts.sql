--create database ProductDB
--go

use Training_19Sep18_Pune
go

create schema Durgesh_Geetha
go

create table Durgesh_Geetha.Category
(
CategoryId int identity(1,1) primary key,
CategoryName varchar(50) not null unique
)

insert into Durgesh_Geetha.Category 
values ('Watches'),('Laptops'),('Mobiles')

create table Durgesh_Geetha.Product
(
ProductId int identity(1,1) primary key,
ProductName varchar(25) unique not null,
[Description] varchar(250) null,
UnitPrice money not null,
Stock int not null,
Category int not null foreign key references Durgesh_Geetha.Category(CategoryId)
)

create proc Durgesh_Geetha.uspAddProduct
(
@pName varchar(25),
@descp varchar(250),
@up money,
@st int,
@cat int,
@pId int output
)
as
begin
	insert into Durgesh_Geetha.Product
	values(@pName,@descp,@up,@st,@cat)
	set @pId = Scope_Identity()
end

create proc Geetha.uspEditProduct
(
@pId int,
@pName varchar(25),
@descp varchar(250),
@up money,
@st int,
@cat int
)
as
begin
	update Durgesh_Geetha.Product
	set ProductName = @pName,[Description]=@descp,
	UnitPrice=@up,Stock=@st,Category=@cat
	where ProductId = @pid
end

create proc Durgesh_Geetha.uspDeleteProduct
(
@pId int
)
as
begin
	delete from Durgesh_Geetha.Product
	where ProductId = @pid
end

create proc Durgesh_Geetha.uspSearchProduct
(
@pId int
)
as
begin
	select * from Durgesh_Geetha.Product
	where ProductId = @pid
end

create proc Durgesh_Geetha.uspGetProducts
as
begin
	select * from Durgesh_Geetha.Product
end

create proc Durgesh_Geetha.uspGetCategories
as
begin
	select CategoryId,CategoryName 
	from Geetha.Category
	order by CategoryId
end

Create proc Durgesh_Geetha.uspNextProductId
as
begin
select IDENT_CURRENT('Durgesh_Geetha.Product') +IDENT_Incr('Durgesh_Geetha.Product') 
end