use Training_19Sep18_Pune

select * from Book_Master

select DB_NAme()
select DB_NAME() as MyCurrentDB


sp_help book_master

create Table ANUj_Employee(Employee_ID int primary key,
First_Name varchar(15) not null,
Last_Name varchar(20) not null,
Age numeric (3),
Email_Id varchar(20) not null);


insert into ANUj_Employee values (161355,'Durgesh','Banote',22,'durgesh.baonte@gmail.com'),(161335,'Akshay','Jain',22, 'akshay.jain@gmail.com'),(160669,'Dheeraj','Patel',23,'dheeraj.patel@gmail.com');
select * from ANUj_Employee;
drop table ANUj_Employee;
create Table ANUJ_Employee(Employee_ID int primary key,
First_Name varchar(15) not null,
Last_Name varchar(20) not null,
Age numeric (3),
Email_Id varchar(20) not null);

select * from ANUJ_Employee;
delete from  ANUJ_Employee;
select * from ANUJ_Employee;
drop table ANUJ_Employee;

create Table ANUj_Employee(Employee_ID int primary key,
First_Name varchar(15) not null,
Last_Name varchar(20) not null,
Age numeric (3),
Email_Id varchar(30));
insert into ANUj_Employee values (161355,'Durgesh','Banote',22,'durgesh.baonte@gmail.com'),(161335,'Akshay','Jain',22, 'akshay.jain@gmail.com'),(160669,'Dheeraj','Patel',23,'dheeraj.patel@gmail.com');

select * from ANUj_Employee;

select * from ANUj_Employee where First_Name like 'D%';

create Type MyTypeInt from  int;

alter table ANUJ_Employee
Add Address varchar(50);
select * from ANUj_Employee;

alter table ANUJ_Employee
Add Gender varchar(10);

alter table ANUJ_Employee
drop column Address;

alter table ANUJ_Employee
add constraint uk_Employee_ID unique(Employee_ID);


alter table ANUJ_Employee
drop column Address;
select * from ANUj_Employee;

alter table ANUJ_Employee
add City varchar(25)not null default 'Pune';

select * from ANUj_Employee;

alter table ANUJ_Employee
drop from ANUJ_Employee column Address;

create table Anuj1Population
(
 country varchar(100),
 [state] varchar(100),
 city varchar(50),
 [Population(in millions)] int
 ) 

 INSERT INTO Anuj1Population VALUES('India', 'Delhi','East Delhi',9 )
 
INSERT INTO Anuj1Population VALUES('India', 'Delhi','South Delhi',8 )
 
INSERT INTO Anuj1Population VALUES('India', 'Delhi','North Delhi',5.5)
 
INSERT INTO Anuj1Population VALUES('India', 'Delhi','West Delhi',7.5)
 
INSERT INTO Anuj1Population VALUES('India', 'Karnataka','Bangalore',9.5)
 
INSERT INTO Anuj1Population VALUES('India', 'Karnataka','Belur',2.5)
 
INSERT INTO Anuj1Population VALUES('India', 'Karnataka','Manipal',1.5)
 
INSERT INTO Anuj1Population VALUES('India', 'Maharastra','Mumbai',30)
 
INSERT INTO Anuj1Population VALUES('India', 'Maharastra','Pune',20)
 
INSERT INTO Anuj1Population VALUES('India', 'Maharastra','Nagpur',11 )
 
INSERT INTO Anuj1Population VALUES('India', 'Maharastra','Nashik',6.5);
select * from Anuj1Population;

select sum([Population(in millions)]) as [total] from Anuj1Population;
select max([Population(in millions)]) as [max] from Anuj1Population;
select min([Population(in millions)]) as [min] from Anuj1Population;
select count([Population(in millions)]) as [count] from Anuj1Population;
select avg([Population(in millions)]) as [avg] from Anuj1Population;

select state, sum([Population(in millions)]) from Anuj1Population
group by state 
having sum([Population(in millions)])>10  order by state;

select * from Anuj1Population where city='pune'or city='nashik'or city= 'belur'
select * from Anuj1Population where city in ('pune','nashik','belur');
select * from Anuj1Population where city like 'b%'

select city  from Anuj1Population where ([Population(in millions)])= (select min([Population(in millions)]) as [min] from Anuj1Population);

create table AnujCustomer
(
Cust_Id numeric(10) primary key,
[CustFName] varchar(20),[CustLName] varchar(20),
ORD_Id int 

);
create table Anuj_Orders
(
O_Id int primary key,
O_Name varchar(50),
);
INSERT INTO AnujCustomer VALUES(001, 'Abhay','Raj',1)
INSERT INTO AnujCustomer VALUES(002, 'Bharat','Singh',2)
INSERT INTO AnujCustomer VALUES(003, 'Chahat','Kumar', 3)
INSERT INTO AnujCustomer VALUES(004, 'Dhruva','Ayyar', 4)
INSERT INTO AnujCustomer VALUES(005, 'Dheeraj','patel', 5)

INSERT INTO Anuj_Orders VALUES(3, 'Poha')
INSERT INTO Anuj_Orders VALUES(4, 'Dosa')
INSERT INTO Anuj_Orders VALUES(5, 'Idli')
INSERT INTO Anuj_Orders VALUES(6, 'Ice-Cream')

Select * from AnujCustomer
full join  Anuj_Order on AnujCustomer.ORD_Id=Anuj_Orders.O_Id;


create function AnujSquare(@v1 int)
returns int
begin
declare @Result int;
set @Result=@v1*@v1;
return @Result
end
Select dbo.AnujSquare(2)

create table AnujStudents
(
[student id] int IDENTITY(1,1)Not null,
[First Name]varchar (200)not null,
[Last Name]varchar (200) null,
[Email]nvarchar(100)null

)

insert into AnujStudents values('Durgesh','Banote','durgesh.baonte@gmail.com'),('Akshay','Jain', 'akshay.jain@gmail.com'),('Dheeraj','Patel','dheeraj.patel@gmail.com');
select * from AnujStudents;

delete from AnujStudents where [student id]=7

alter procedure GetStudentName(@S_id int,@email varchar(30))
as
begin
select [First Name]+''+[Last Name]+''+email from AnujStudents where [student id]=@S_id and [Email]=@email
 end

 exec GetStudentName 4,'durgesh.baonte@gmail.com';



 alter procedure GetStudentName(@S_id int,@email varchar(30) OUT)
as
begin
select @email=[First Name]+''+[Last Name]+''+email from AnujStudents where [student id]=@S_id;
 end

 declare @FullDescription varchar(100)
 exec GetStudentName 4,@FullDescription output
 select @FullDescription as Name
-- ==================================================
-- Copy Data from One table to Other Using procedure
--===================================================

 create table AnujStudent3
 (
[student id] int Not null,
[First Name]varchar (200)not null,
[Last Name]varchar (200) null,
[Email]nvarchar(100)null

)
 alter procedure CopyData12(@id int)
as
begin
declare @fname varchar(20),@lname varchar(20),@email varchar(30);
select @fname =[First name],@lname=[Last Name],@email=Email  from AnujStudents
where [student id]= @id
insert into AnujStudent3
values(4,@fname,@lname,@email)

 end
 exec CopyData12 4;
 --=================================
 -- --KCopy Data from One table to Other
 --=================================
 select * from AnujStudents
 select *from AnujStudent3
 insert into AnujStudent2  select * from AnujStudents where [student id];

 --======================================
 --           Triggers
 --======================================


drop TABLE Anuj_Employee_Test
(
Emp_ID INT Identity,
Emp_name Varchar(100),
Emp_Sal Decimal (10,2)
)

INSERT INTO Anuj_Employee_Test VALUES ('Anees',1000);
INSERT INTO Anuj_Employee_Test VALUES ('Rick',1200);
INSERT INTO Anuj_Employee_Test VALUES ('John',1100);
INSERT INTO Anuj_Employee_Test VALUES ('Stephen',1300);
INSERT INTO Anuj_Employee_Test VALUES ('Maria',1400);
 
 select * from Anuj_Employee_Test

drop TABLE Anuj_Employee_Test_Audit
(
Emp_ID int,
Emp_name varchar(100),
Emp_Sal decimal (10,2),
Audit_Action varchar(100),
Audit_Timestamp datetime
)

alter TRIGGER trgAfterInsert51 ON Anuj_Employee_Test 
FOR INSERT
AS
	declare @empid int;
	declare @empname varchar(100);
	declare @empsal decimal(10,2);
	declare @audit_action varchar(100);

	select @empid=i.Emp_ID from inserted i;	
	select @empname=i.Emp_Name from inserted i;	
	select @empsal=i.Emp_Sal from inserted i;	
	set @audit_action='Inserted Record -- After Insert Trigger.';

	insert into Anuj_Employee_Test
        
		   (Emp_ID,Emp_Name,Emp_Sal,Audit_Action,Audit_Timestamp) 
	values(@empid,@empname,@empsal,@audit_action,getdate());

	PRINT 'AFTER INSERT trigger fired.'
GO
Select* from Anuj_Employee_Test 
insert into  Anuj_Employee_Test values('Chris',1500);

--========================================================
--========================================================


select * from ANUj_Employee
alter table ANUj_Employee
drop column age
exec sp_help ANUj_Employee
create CLUSTERED INDEX anuj_employee on Anuj_Employee(First_name asc,);

select * from ANUj_Employee

--=================================
--      Self Join
--=================================
create table AnujEmployee(
employeeId int primary key,
Name nvarchar(50),
ManagerId int
)

insert into AnujEmployee
select 1,'Mike',3
union all 
select 2, 'David',3
union all
select 3 ,'Roger' ,NULL
union all
select 4 ,'Marry', 2
union all
select 5 ,'Joseph', 2
union all
select 6 ,'Ben', 2

select * from AnujEmployee

select e1.Name as EmployeeName,e2.Name as ManagerName from AnujEmployee e1
full join AnujEmployee e2
on e1.ManagerId=e2.EmployeeId


select * from Anuj_Orders;
Select * from AnujCustomer; 

full join Anuj_Orders on Anujcustomer.
--=================================================
-- Exception Handling in SQL
--================================================

create table Anuj_dept
(
v_deptcode int primary key,
v_deptname varchar(10)

)
declare @v_deptcode int 
declare @v_deptname varchar(10)
declare @errorcode int
set  @v_deptcode= 10;
set @v_deptname ='Pre sales'

insert into Anuj_dept values(@v_deptcode,'Pre sales')

set @errorcode= @@ERROR
if @errorcode>0
begin
print 'error'
print @errorcode
end
else
print 'added successfully'

--=====================================================
--Using Try And Catch Block
--=====================================================

declare @v_deptcode int 
declare @v_deptname varchar(10)
declare @errorcode int
set  @v_deptcode= 10;
set @v_deptname ='Pre sales'

begin try
insert into Anuj_dept values(@v_deptcode,'Pre sales')

end try
begin catch
print 'An error is occured while inserting'
print Error_number()
end Catch

=======================================================

========================================================


