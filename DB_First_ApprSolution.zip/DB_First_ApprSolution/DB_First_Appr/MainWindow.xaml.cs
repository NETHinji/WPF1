﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DB_First_Appr
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //Creating Connection
        public string constr = @"data source=ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog=Training_19Sep18_Pune";

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string value = cmbDemo.SelectedValue.ToString();
            SqlConnection con = new SqlConnection(constr);
            DataTable dt = new DataTable();
            SqlCommand com = new SqlCommand("Dheeraj_ProductDetails", con);
            com.Parameters.AddWithValue("@pType", value);

            com.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                dt.Load(dr);
                dgDisplay.ItemsSource = dt.DefaultView;
            }
            else
                MessageBox.Show("No values found");

            con.Close(); //Closing Connection
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var student in Enum.GetValues(typeof(ProductTypeEnum)))
            {
                cmbDemo.Items.Add(student);
            }
        }
    }
}
