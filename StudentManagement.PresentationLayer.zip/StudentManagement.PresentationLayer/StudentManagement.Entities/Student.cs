﻿namespace StudentManagement.Entities
{
    public class Student
    {
        public static int StudId { get; set; }
        public static int StudName { get; set; }
        public static int StudContactNumber { get; set; }
        public static int StudEmail { get; set; }
    }
}