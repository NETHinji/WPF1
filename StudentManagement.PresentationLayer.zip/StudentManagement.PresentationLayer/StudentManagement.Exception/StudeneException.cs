﻿using System;
using System.Runtime.Serialization;

namespace StudentManagement.Exception
{
    [Serializable]
    public class StudeneException : System.Exception
    {
        public StudeneException()
        {
        }

        public StudeneException(string message) : base(message)
        {
        }

        public StudeneException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected StudeneException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}