create schema CapG

create table CapG.Ar_Emp
(
Employee_Id  int identity(1,1) primary key,
Employee_Nmae varchar(30) not null,
Employee_Emailid varchar(50) not null,
Employee_contact numeric(10)
)

select * from CapG.Ar_Emp
------------------ADD PROCEDURE-------------------

create proc CapG.AddEMp
(
@eName varchar(30),
@eEmail varchar(50),
@eContact numeric,
@eId int output
)
as
begin
	insert into CapG.Ar_Emp
	values(@eName,@eEmail,@eContact)
	set @eId = Scope_Identity()
end

------------------DELETE PROCEDURE-------------------

create proc CapG.DeleteEmp
(
@eId int
)
as
begin
	delete from CapG.Ar_Emp
	where Employee_Id = @eid
end

------------------SELECT ALL PROCEDURE-------------------
create proc CapG.SelectAll
as
begin
   select * from CapG.Ar_Emp
end

--------------------UPDATE PROCEDURE---------------------
alter proc CapG.UpdateEmp
(
@eName varchar(30),
@eEmail varchar(50),
@eContact numeric,
@eid int
)
as
begin
	update CapG.Ar_Emp set Employee_Nmae=@eName,Employee_Emailid=@eEmail,Employee_contact=@eContact
	where Employee_Id=@eid
end

--------------------SELECT MENTIONE PROCEDURE---------------------

create proc CapG.SelectChoice
(
@eId int
)
as 
begin
    select * from Capg.Ar_Emp where Employee_Id=@eId
end
