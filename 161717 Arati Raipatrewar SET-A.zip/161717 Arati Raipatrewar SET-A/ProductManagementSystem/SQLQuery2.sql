-----------Creating schema-------
create schema ArRai 


----------Creating table-----------

create table ArRai.Product
(
SerialNumber varchar(14) primary key,
Productname varchar(30),
Brandname varchar(30),
ProductType varchar(30),
check (ProductType in ('Mobiles','Cameras','Laptops','Appliances','Accessories')),                                                 
ProductDesc varchar(100),
Price int
check (price>0)
)

----------Creating Add Procedure----------- 

alter proc ArRai.AddProduct
(
@sNumber varchar(14),
@pName varchar(30),
@bname varchar(30),
@pType varchar(30),
@pDesc varchar(100),
@price int
)
as
begin 
	insert into ArRai.Product values (@sNumber,@pName,@bname,@pType,@pDesc,@price)
end


select * from ArRai.Product

----------Listing table-----------

create proc ArRai.List
as
begin
	select * from ArRai.Product
end









